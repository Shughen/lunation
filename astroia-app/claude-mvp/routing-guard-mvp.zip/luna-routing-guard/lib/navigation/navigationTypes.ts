/**
 * LUNA - Cycle & Cosmos
 * Navigation Types - Types centralisés pour le routing
 * 
 * Ce fichier définit tous les types liés à la navigation de l'application.
 * Il sert de "contrat" entre le routing guard et le reste de l'app.
 * 
 * @version 1.0.0
 * @date 27 novembre 2025
 */

/**
 * État de navigation calculé à partir des différents stores.
 * Utilisé par le routing guard pour déterminer la route cible.
 */
export interface NavigationState {
  /** L'utilisateur a une session Supabase active */
  isAuthenticated: boolean;
  
  /** L'utilisateur a complété le flow d'onboarding (welcome screen vu) */
  hasCompletedOnboarding: boolean;
  
  /** Le profil utilisateur contient toutes les infos requises (nom, date/heure/lieu naissance) */
  hasValidProfile: boolean;
  
  /** Le cycle menstruel est configuré (dernières règles + durée cycle) */
  hasCycleSetup: boolean;
  
  /** L'app est en cours d'initialisation (chargement stores) */
  isInitializing: boolean;
}

/**
 * Routes principales de l'application.
 * Utilise la syntaxe Expo Router avec groupes de routes.
 */
export type AppRoute =
  // Routes d'authentification (non authentifié)
  | '/(auth)/login'
  | '/(auth)/signup'
  | '/(auth)/verify-otp'
  | '/(auth)/forgot-password'
  // Routes d'onboarding (authentifié mais setup incomplet)
  | '/onboarding'
  | '/onboarding/welcome'
  | '/onboarding/consent'
  | '/onboarding/profile-setup'
  | '/onboarding/cycle-setup'
  | '/onboarding/tour'
  // Routes principales (authentifié et setup complet)
  | '/(tabs)'
  | '/(tabs)/home'
  | '/(tabs)/chat'
  | '/(tabs)/calendar'
  | '/(tabs)/profile'
  // Routes modales/secondaires
  | '/natal-chart'
  | '/lunar-revolution'
  | '/settings'
  | '/settings/privacy'
  | '/settings/notifications'
  | '/settings/account';

/**
 * Routes publiques accessibles sans authentification.
 */
export const PUBLIC_ROUTES: readonly string[] = [
  '/(auth)/login',
  '/(auth)/signup',
  '/(auth)/verify-otp',
  '/(auth)/forgot-password',
] as const;

/**
 * Routes d'onboarding dans l'ordre du flow.
 */
export const ONBOARDING_ROUTES: readonly string[] = [
  '/onboarding',
  '/onboarding/welcome',
  '/onboarding/consent',
  '/onboarding/profile-setup',
  '/onboarding/cycle-setup',
  '/onboarding/tour',
] as const;

/**
 * Routes principales de l'app (tabs).
 */
export const MAIN_ROUTES: readonly string[] = [
  '/(tabs)',
  '/(tabs)/home',
  '/(tabs)/chat',
  '/(tabs)/calendar',
  '/(tabs)/profile',
] as const;

/**
 * Routes protégées nécessitant authentification.
 */
export const PROTECTED_ROUTES: readonly string[] = [
  ...ONBOARDING_ROUTES,
  ...MAIN_ROUTES,
  '/natal-chart',
  '/lunar-revolution',
  '/settings',
  '/settings/privacy',
  '/settings/notifications',
  '/settings/account',
] as const;

/**
 * Configuration d'une transition de navigation.
 */
export interface NavigationTransition {
  /** Route de départ */
  from: string;
  /** Route de destination */
  to: string;
  /** État de navigation au moment de la transition */
  state: NavigationState;
  /** Timestamp de la transition */
  timestamp: number;
}

/**
 * Résultat de la validation d'une transition.
 */
export interface TransitionValidationResult {
  /** La transition est-elle autorisée ? */
  isValid: boolean;
  /** Route recommandée si la transition n'est pas valide */
  suggestedRoute?: AppRoute;
  /** Raison du refus (pour debug) */
  reason?: string;
}

/**
 * Options pour le routing guard.
 */
export interface RoutingGuardOptions {
  /** Activer les logs de debug */
  debug?: boolean;
  /** Délai minimum entre deux redirections (évite boucles) */
  minRedirectDelay?: number;
  /** Callback appelé avant chaque redirection */
  onBeforeRedirect?: (transition: NavigationTransition) => void;
  /** Callback appelé après chaque redirection */
  onAfterRedirect?: (transition: NavigationTransition) => void;
}

/**
 * État interne du routing guard pour éviter les boucles.
 */
export interface RoutingGuardInternalState {
  /** Dernière redirection effectuée */
  lastRedirect: NavigationTransition | null;
  /** Nombre de redirections dans la fenêtre de temps */
  redirectCount: number;
  /** Timestamp de reset du compteur */
  redirectCountResetTime: number;
}

/**
 * Profile minimal requis pour validation.
 * Utilisé pour vérifier si le profil est "valide" (complet).
 */
export interface MinimalProfile {
  id?: string;
  name?: string | null;
  birth_date?: string | null;
  birth_time?: string | null;
  birth_location?: string | null;
  birth_latitude?: number | null;
  birth_longitude?: number | null;
  last_period?: string | null;
  cycle_length?: number | null;
}

/**
 * Type guard pour vérifier si une route est une AppRoute valide.
 */
export function isValidAppRoute(route: string): route is AppRoute {
  const allRoutes: string[] = [
    ...PUBLIC_ROUTES,
    ...PROTECTED_ROUTES,
  ];
  return allRoutes.includes(route);
}

/**
 * Type guard pour vérifier si un objet est un NavigationState valide.
 */
export function isValidNavigationState(obj: unknown): obj is NavigationState {
  if (typeof obj !== 'object' || obj === null) return false;
  
  const state = obj as Record<string, unknown>;
  return (
    typeof state.isAuthenticated === 'boolean' &&
    typeof state.hasCompletedOnboarding === 'boolean' &&
    typeof state.hasValidProfile === 'boolean' &&
    typeof state.hasCycleSetup === 'boolean' &&
    typeof state.isInitializing === 'boolean'
  );
}

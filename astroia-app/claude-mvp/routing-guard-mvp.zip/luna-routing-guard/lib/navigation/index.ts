/**
 * LUNA - Cycle & Cosmos
 * Navigation Module - Exports centralisés
 * 
 * @version 1.0.0
 */

// Types
export type {
  NavigationState,
  AppRoute,
  NavigationTransition,
  TransitionValidationResult,
  RoutingGuardOptions,
  RoutingGuardInternalState,
  MinimalProfile,
} from './navigationTypes';

// Constants
export {
  PUBLIC_ROUTES,
  ONBOARDING_ROUTES,
  MAIN_ROUTES,
  PROTECTED_ROUTES,
  isValidAppRoute,
  isValidNavigationState,
} from './navigationTypes';

// Guard Functions
export {
  determineRoute,
  isPublicRoute,
  isOnboardingRoute,
  isMainRoute,
  validateTransition,
  shouldRedirect,
  recordRedirect,
  resetRoutingGuard,
  normalizeRoute,
  getRouteGroup,
  getTransitionDebugInfo,
  createTransition,
  createDefaultNavigationState,
  hasNavigationStateChanged,
} from './routingGuard';

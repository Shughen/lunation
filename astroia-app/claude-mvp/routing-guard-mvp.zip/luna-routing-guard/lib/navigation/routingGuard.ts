/**
 * LUNA - Cycle & Cosmos
 * Routing Guard - Source unique de vérité pour la navigation
 * 
 * Ce module centralise TOUTE la logique de routing de l'application.
 * Aucun autre fichier ne doit contenir de logique de redirection.
 * 
 * Principe : 
 * - determineRoute() calcule la route cible selon l'état
 * - validateTransition() valide si une transition est autorisée
 * - Le RootLayout utilise ces fonctions pour rediriger
 * 
 * @version 1.0.0
 * @date 27 novembre 2025
 */

import {
  NavigationState,
  AppRoute,
  PUBLIC_ROUTES,
  ONBOARDING_ROUTES,
  MAIN_ROUTES,
  NavigationTransition,
  TransitionValidationResult,
  RoutingGuardOptions,
  RoutingGuardInternalState,
} from './navigationTypes';

// ============================================================================
// CONFIGURATION
// ============================================================================

/** Délai minimum entre deux redirections (ms) pour éviter boucles */
const MIN_REDIRECT_DELAY = 100;

/** Nombre max de redirections par seconde avant détection boucle */
const MAX_REDIRECTS_PER_SECOND = 5;

/** Fenêtre de temps pour compter les redirections (ms) */
const REDIRECT_COUNT_WINDOW = 1000;

// État interne pour éviter les boucles
let internalState: RoutingGuardInternalState = {
  lastRedirect: null,
  redirectCount: 0,
  redirectCountResetTime: Date.now(),
};

// ============================================================================
// FONCTIONS PRINCIPALES
// ============================================================================

/**
 * Détermine la route cible en fonction de l'état de navigation.
 * C'est LA fonction centrale qui décide où l'utilisateur doit être.
 * 
 * @param state - État de navigation actuel
 * @returns Route cible où l'utilisateur doit être redirigé
 * 
 * @example
 * const state = useNavigationState();
 * const targetRoute = determineRoute(state);
 * // '/(auth)/login' si non authentifié
 * // '/onboarding' si auth mais onboarding non complété
 * // '/(tabs)/home' si tout est OK
 */
export function determineRoute(state: NavigationState): AppRoute {
  // 1. Si initialisation en cours, ne pas rediriger (laisser splash screen)
  // Note: On retourne quand même une route mais le composant parent
  // doit gérer l'état isInitializing pour afficher un loader
  
  // 2. Non authentifié → Login
  if (!state.isAuthenticated) {
    return '/(auth)/login';
  }
  
  // 3. Authentifié mais onboarding non complété → Onboarding
  if (!state.hasCompletedOnboarding) {
    return '/onboarding';
  }
  
  // 4. Onboarding fait mais profil incomplet → Profile setup
  if (!state.hasValidProfile) {
    return '/onboarding/profile-setup';
  }
  
  // 5. Profil OK mais cycle non configuré → Cycle setup
  if (!state.hasCycleSetup) {
    return '/onboarding/cycle-setup';
  }
  
  // 6. Tout est OK → Home
  return '/(tabs)/home';
}

/**
 * Vérifie si une route est publique (accessible sans auth).
 * 
 * @param route - Route à vérifier
 * @returns true si la route est publique
 */
export function isPublicRoute(route: string): boolean {
  return PUBLIC_ROUTES.some(publicRoute => 
    route === publicRoute || route.startsWith(publicRoute.split('/').slice(0, -1).join('/') + '/')
  );
}

/**
 * Vérifie si une route fait partie de l'onboarding.
 * 
 * @param route - Route à vérifier
 * @returns true si c'est une route d'onboarding
 */
export function isOnboardingRoute(route: string): boolean {
  return ONBOARDING_ROUTES.some(onboardingRoute =>
    route === onboardingRoute || route.startsWith('/onboarding')
  );
}

/**
 * Vérifie si une route fait partie des tabs principales.
 * 
 * @param route - Route à vérifier
 * @returns true si c'est une route de tabs
 */
export function isMainRoute(route: string): boolean {
  return MAIN_ROUTES.some(mainRoute =>
    route === mainRoute || route.startsWith('/(tabs)')
  );
}

/**
 * Valide si une transition de navigation est autorisée.
 * Utilisé pour empêcher les navigations non autorisées.
 * 
 * @param from - Route actuelle
 * @param to - Route de destination
 * @param state - État de navigation
 * @returns Résultat de validation avec route suggérée si invalide
 */
export function validateTransition(
  from: string,
  to: string,
  state: NavigationState
): TransitionValidationResult {
  // Si initialisation en cours, bloquer toute navigation
  if (state.isInitializing) {
    return {
      isValid: false,
      reason: 'App is initializing',
    };
  }
  
  // Calculer la route autorisée
  const allowedRoute = determineRoute(state);
  
  // Route publique → toujours autorisée (pour auth)
  if (isPublicRoute(to)) {
    // Mais si authentifié, rediriger vers route appropriée
    if (state.isAuthenticated) {
      return {
        isValid: false,
        suggestedRoute: allowedRoute,
        reason: 'Already authenticated, redirecting to appropriate route',
      };
    }
    return { isValid: true };
  }
  
  // Non authentifié essaie d'accéder à route protégée
  if (!state.isAuthenticated) {
    return {
      isValid: false,
      suggestedRoute: '/(auth)/login',
      reason: 'Not authenticated',
    };
  }
  
  // Navigation libre dans l'onboarding tant que non complété
  if (isOnboardingRoute(to) && !state.hasCompletedOnboarding) {
    return { isValid: true };
  }
  
  // Navigation libre dans onboarding pour setup profil/cycle
  if (isOnboardingRoute(to) && (!state.hasValidProfile || !state.hasCycleSetup)) {
    return { isValid: true };
  }
  
  // Navigation libre dans les tabs si tout est OK
  if (isMainRoute(to) && state.hasValidProfile && state.hasCycleSetup) {
    return { isValid: true };
  }
  
  // Si on essaie d'aller ailleurs que la route autorisée
  if (to !== allowedRoute && !isSubRouteOf(to, allowedRoute)) {
    return {
      isValid: false,
      suggestedRoute: allowedRoute,
      reason: `Navigation to ${to} not allowed in current state`,
    };
  }
  
  return { isValid: true };
}

/**
 * Vérifie si une route est une sous-route d'une autre.
 * Ex: '/onboarding/profile-setup' est sous-route de '/onboarding'
 */
function isSubRouteOf(route: string, parentRoute: string): boolean {
  if (route === parentRoute) return true;
  
  // Cas spécial pour les tabs
  if (parentRoute === '/(tabs)/home' && route.startsWith('/(tabs)')) {
    return true;
  }
  
  // Cas spécial pour onboarding
  if (parentRoute === '/onboarding' && route.startsWith('/onboarding')) {
    return true;
  }
  
  return route.startsWith(parentRoute + '/');
}

/**
 * Vérifie si une redirection doit être effectuée.
 * Gère la détection de boucles infinies.
 * 
 * @param currentRoute - Route actuelle
 * @param targetRoute - Route cible
 * @param options - Options du guard
 * @returns true si la redirection doit être effectuée
 */
export function shouldRedirect(
  currentRoute: string,
  targetRoute: string,
  options: RoutingGuardOptions = {}
): boolean {
  const { debug = false, minRedirectDelay = MIN_REDIRECT_DELAY } = options;
  const now = Date.now();
  
  // Même route → pas de redirection
  if (normalizeRoute(currentRoute) === normalizeRoute(targetRoute)) {
    if (debug) {
      console.log('[RoutingGuard] Same route, no redirect needed');
    }
    return false;
  }
  
  // Reset compteur si fenêtre dépassée
  if (now - internalState.redirectCountResetTime > REDIRECT_COUNT_WINDOW) {
    internalState.redirectCount = 0;
    internalState.redirectCountResetTime = now;
  }
  
  // Vérifier si on est en boucle
  if (internalState.redirectCount >= MAX_REDIRECTS_PER_SECOND) {
    if (debug) {
      console.warn('[RoutingGuard] Too many redirects detected, blocking');
    }
    return false;
  }
  
  // Vérifier délai minimum
  if (internalState.lastRedirect) {
    const timeSinceLastRedirect = now - internalState.lastRedirect.timestamp;
    if (timeSinceLastRedirect < minRedirectDelay) {
      if (debug) {
        console.log('[RoutingGuard] Too soon since last redirect, skipping');
      }
      return false;
    }
  }
  
  // Incrémenter compteur
  internalState.redirectCount++;
  
  if (debug) {
    console.log(`[RoutingGuard] Redirect allowed: ${currentRoute} → ${targetRoute}`);
  }
  
  return true;
}

/**
 * Enregistre une redirection effectuée.
 * À appeler après chaque router.replace() réussi.
 * 
 * @param transition - Détails de la transition
 */
export function recordRedirect(transition: NavigationTransition): void {
  internalState.lastRedirect = transition;
}

/**
 * Réinitialise l'état interne du guard.
 * Utile pour les tests ou après un logout.
 */
export function resetRoutingGuard(): void {
  internalState = {
    lastRedirect: null,
    redirectCount: 0,
    redirectCountResetTime: Date.now(),
  };
}

// ============================================================================
// FONCTIONS UTILITAIRES
// ============================================================================

/**
 * Normalise une route pour comparaison.
 * Supprime les trailing slashes et paramètres.
 */
export function normalizeRoute(route: string): string {
  // Supprimer trailing slash
  let normalized = route.endsWith('/') && route !== '/' 
    ? route.slice(0, -1) 
    : route;
  
  // Supprimer query params
  const queryIndex = normalized.indexOf('?');
  if (queryIndex !== -1) {
    normalized = normalized.substring(0, queryIndex);
  }
  
  // Gérer la route racine
  if (normalized === '' || normalized === '/index') {
    normalized = '/';
  }
  
  return normalized;
}

/**
 * Extrait le groupe de route (auth, tabs, onboarding).
 */
export function getRouteGroup(route: string): 'auth' | 'tabs' | 'onboarding' | 'other' {
  if (route.includes('(auth)') || route.startsWith('/login') || route.startsWith('/signup')) {
    return 'auth';
  }
  if (route.includes('(tabs)') || route.startsWith('/home')) {
    return 'tabs';
  }
  if (route.startsWith('/onboarding')) {
    return 'onboarding';
  }
  return 'other';
}

/**
 * Génère un message de debug pour une transition.
 */
export function getTransitionDebugInfo(
  from: string,
  to: string,
  state: NavigationState
): string {
  return `
[RoutingGuard] Transition Debug:
  From: ${from}
  To: ${to}
  State:
    - isAuthenticated: ${state.isAuthenticated}
    - hasCompletedOnboarding: ${state.hasCompletedOnboarding}
    - hasValidProfile: ${state.hasValidProfile}
    - hasCycleSetup: ${state.hasCycleSetup}
    - isInitializing: ${state.isInitializing}
  Target Route: ${determineRoute(state)}
`.trim();
}

/**
 * Crée un objet NavigationTransition.
 */
export function createTransition(
  from: string,
  to: string,
  state: NavigationState
): NavigationTransition {
  return {
    from,
    to,
    state,
    timestamp: Date.now(),
  };
}

// ============================================================================
// HOOKS HELPERS
// ============================================================================

/**
 * Crée un état de navigation par défaut (non initialisé).
 */
export function createDefaultNavigationState(): NavigationState {
  return {
    isAuthenticated: false,
    hasCompletedOnboarding: false,
    hasValidProfile: false,
    hasCycleSetup: false,
    isInitializing: true,
  };
}

/**
 * Compare deux états de navigation pour détecter les changements.
 */
export function hasNavigationStateChanged(
  prev: NavigationState,
  next: NavigationState
): boolean {
  return (
    prev.isAuthenticated !== next.isAuthenticated ||
    prev.hasCompletedOnboarding !== next.hasCompletedOnboarding ||
    prev.hasValidProfile !== next.hasValidProfile ||
    prev.hasCycleSetup !== next.hasCycleSetup ||
    prev.isInitializing !== next.isInitializing
  );
}

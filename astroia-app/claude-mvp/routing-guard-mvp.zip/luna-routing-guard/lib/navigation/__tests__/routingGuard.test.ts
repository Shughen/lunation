/**
 * LUNA - Cycle & Cosmos
 * Tests unitaires pour le Routing Guard
 * 
 * Couvre tous les cas de navigation déterministe.
 * 
 * @version 1.0.0
 * @date 27 novembre 2025
 */

import {
  determineRoute,
  isPublicRoute,
  isOnboardingRoute,
  isMainRoute,
  validateTransition,
  shouldRedirect,
  resetRoutingGuard,
  normalizeRoute,
  getRouteGroup,
  createDefaultNavigationState,
  hasNavigationStateChanged,
} from '../routingGuard';

import type { NavigationState } from '../navigationTypes';

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Crée un état de navigation pour les tests
 */
function createState(overrides: Partial<NavigationState> = {}): NavigationState {
  return {
    isAuthenticated: false,
    hasCompletedOnboarding: false,
    hasValidProfile: false,
    hasCycleSetup: false,
    isInitializing: false,
    ...overrides,
  };
}

// ============================================================================
// TESTS: determineRoute
// ============================================================================

describe('determineRoute', () => {
  beforeEach(() => {
    resetRoutingGuard();
  });

  describe('Cas non authentifié', () => {
    it('redirige vers login si non authentifié', () => {
      const state = createState({
        isAuthenticated: false,
      });
      expect(determineRoute(state)).toBe('/(auth)/login');
    });

    it('redirige vers login même si onboarding est complété mais non auth', () => {
      const state = createState({
        isAuthenticated: false,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: true,
      });
      expect(determineRoute(state)).toBe('/(auth)/login');
    });
  });

  describe('Cas authentifié - Onboarding non complété', () => {
    it('redirige vers onboarding si auth mais onboarding non fait', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: false,
      });
      expect(determineRoute(state)).toBe('/onboarding');
    });

    it('redirige vers onboarding même avec profil complet si onboarding pas fait', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: false,
        hasValidProfile: true,
        hasCycleSetup: true,
      });
      expect(determineRoute(state)).toBe('/onboarding');
    });
  });

  describe('Cas authentifié - Profil incomplet', () => {
    it('redirige vers profile-setup si onboarding fait mais profil incomplet', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: false,
      });
      expect(determineRoute(state)).toBe('/onboarding/profile-setup');
    });

    it('redirige vers profile-setup même si cycle configuré mais profil incomplet', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: false,
        hasCycleSetup: true,
      });
      expect(determineRoute(state)).toBe('/onboarding/profile-setup');
    });
  });

  describe('Cas authentifié - Cycle non configuré', () => {
    it('redirige vers cycle-setup si profil OK mais cycle non configuré', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: false,
      });
      expect(determineRoute(state)).toBe('/onboarding/cycle-setup');
    });
  });

  describe('Cas happy path - Tout est OK', () => {
    it('redirige vers home si toutes les conditions sont remplies', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: true,
      });
      expect(determineRoute(state)).toBe('/(tabs)/home');
    });
  });

  describe('Ordre de priorité des conditions', () => {
    it('vérifie auth AVANT onboarding', () => {
      // Si pas auth, on ne vérifie même pas onboarding
      const state = createState({
        isAuthenticated: false,
        hasCompletedOnboarding: true, // Ignoré car pas auth
      });
      expect(determineRoute(state)).toBe('/(auth)/login');
    });

    it('vérifie onboarding AVANT profil', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: false,
        hasValidProfile: true, // Ignoré car onboarding pas fait
      });
      expect(determineRoute(state)).toBe('/onboarding');
    });

    it('vérifie profil AVANT cycle', () => {
      const state = createState({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: false,
        hasCycleSetup: true, // Ignoré car profil incomplet
      });
      expect(determineRoute(state)).toBe('/onboarding/profile-setup');
    });
  });
});

// ============================================================================
// TESTS: isPublicRoute
// ============================================================================

describe('isPublicRoute', () => {
  it('retourne true pour login', () => {
    expect(isPublicRoute('/(auth)/login')).toBe(true);
  });

  it('retourne true pour signup', () => {
    expect(isPublicRoute('/(auth)/signup')).toBe(true);
  });

  it('retourne true pour verify-otp', () => {
    expect(isPublicRoute('/(auth)/verify-otp')).toBe(true);
  });

  it('retourne false pour home', () => {
    expect(isPublicRoute('/(tabs)/home')).toBe(false);
  });

  it('retourne false pour onboarding', () => {
    expect(isPublicRoute('/onboarding')).toBe(false);
  });

  it('retourne false pour profile', () => {
    expect(isPublicRoute('/(tabs)/profile')).toBe(false);
  });
});

// ============================================================================
// TESTS: isOnboardingRoute
// ============================================================================

describe('isOnboardingRoute', () => {
  it('retourne true pour /onboarding', () => {
    expect(isOnboardingRoute('/onboarding')).toBe(true);
  });

  it('retourne true pour /onboarding/profile-setup', () => {
    expect(isOnboardingRoute('/onboarding/profile-setup')).toBe(true);
  });

  it('retourne true pour /onboarding/cycle-setup', () => {
    expect(isOnboardingRoute('/onboarding/cycle-setup')).toBe(true);
  });

  it('retourne false pour home', () => {
    expect(isOnboardingRoute('/(tabs)/home')).toBe(false);
  });

  it('retourne false pour login', () => {
    expect(isOnboardingRoute('/(auth)/login')).toBe(false);
  });
});

// ============================================================================
// TESTS: isMainRoute
// ============================================================================

describe('isMainRoute', () => {
  it('retourne true pour /(tabs)/home', () => {
    expect(isMainRoute('/(tabs)/home')).toBe(true);
  });

  it('retourne true pour /(tabs)/chat', () => {
    expect(isMainRoute('/(tabs)/chat')).toBe(true);
  });

  it('retourne true pour /(tabs)/profile', () => {
    expect(isMainRoute('/(tabs)/profile')).toBe(true);
  });

  it('retourne false pour onboarding', () => {
    expect(isMainRoute('/onboarding')).toBe(false);
  });

  it('retourne false pour login', () => {
    expect(isMainRoute('/(auth)/login')).toBe(false);
  });
});

// ============================================================================
// TESTS: validateTransition
// ============================================================================

describe('validateTransition', () => {
  beforeEach(() => {
    resetRoutingGuard();
  });

  describe('Non authentifié', () => {
    const state = createState({ isAuthenticated: false });

    it('autorise la navigation vers login', () => {
      const result = validateTransition('/', '/(auth)/login', state);
      expect(result.isValid).toBe(true);
    });

    it('autorise la navigation vers signup', () => {
      const result = validateTransition('/(auth)/login', '/(auth)/signup', state);
      expect(result.isValid).toBe(true);
    });

    it('bloque la navigation vers home', () => {
      const result = validateTransition('/(auth)/login', '/(tabs)/home', state);
      expect(result.isValid).toBe(false);
      expect(result.suggestedRoute).toBe('/(auth)/login');
    });

    it('bloque la navigation vers onboarding', () => {
      const result = validateTransition('/(auth)/login', '/onboarding', state);
      expect(result.isValid).toBe(false);
    });
  });

  describe('Authentifié - Onboarding non fait', () => {
    const state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: false,
    });

    it('autorise la navigation dans onboarding', () => {
      const result = validateTransition('/onboarding', '/onboarding/consent', state);
      expect(result.isValid).toBe(true);
    });

    it('redirige si on tente d\'aller vers home', () => {
      const result = validateTransition('/onboarding', '/(tabs)/home', state);
      expect(result.isValid).toBe(false);
      expect(result.suggestedRoute).toBe('/onboarding');
    });
  });

  describe('Authentifié - Tout OK', () => {
    const state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: true,
    });

    it('autorise la navigation dans les tabs', () => {
      const result = validateTransition('/(tabs)/home', '/(tabs)/chat', state);
      expect(result.isValid).toBe(true);
    });

    it('autorise la navigation vers profile', () => {
      const result = validateTransition('/(tabs)/home', '/(tabs)/profile', state);
      expect(result.isValid).toBe(true);
    });

    it('redirige si on tente d\'aller vers login (déjà auth)', () => {
      const result = validateTransition('/(tabs)/home', '/(auth)/login', state);
      expect(result.isValid).toBe(false);
      expect(result.suggestedRoute).toBe('/(tabs)/home');
    });
  });

  describe('En initialisation', () => {
    const state = createState({ isInitializing: true });

    it('bloque toute navigation pendant l\'initialisation', () => {
      const result = validateTransition('/', '/(auth)/login', state);
      expect(result.isValid).toBe(false);
      expect(result.reason).toContain('initializing');
    });
  });
});

// ============================================================================
// TESTS: shouldRedirect
// ============================================================================

describe('shouldRedirect', () => {
  beforeEach(() => {
    resetRoutingGuard();
  });

  it('retourne false si même route', () => {
    expect(shouldRedirect('/(tabs)/home', '/(tabs)/home')).toBe(false);
  });

  it('retourne true si routes différentes', () => {
    expect(shouldRedirect('/(auth)/login', '/(tabs)/home')).toBe(true);
  });

  it('gère les trailing slashes', () => {
    expect(shouldRedirect('/(tabs)/home/', '/(tabs)/home')).toBe(false);
  });

  it('détecte les boucles (trop de redirections)', () => {
    // Simuler plusieurs redirections rapides
    for (let i = 0; i < 10; i++) {
      shouldRedirect(`/route${i}`, `/route${i + 1}`);
    }
    // La prochaine devrait être bloquée
    expect(shouldRedirect('/routeA', '/routeB')).toBe(false);
  });
});

// ============================================================================
// TESTS: normalizeRoute
// ============================================================================

describe('normalizeRoute', () => {
  it('supprime les trailing slashes', () => {
    expect(normalizeRoute('/(tabs)/home/')).toBe('/(tabs)/home');
  });

  it('préserve la route racine', () => {
    expect(normalizeRoute('/')).toBe('/');
  });

  it('supprime les query params', () => {
    expect(normalizeRoute('/(tabs)/home?foo=bar')).toBe('/(tabs)/home');
  });

  it('gère la route vide', () => {
    expect(normalizeRoute('')).toBe('/');
  });

  it('gère /index', () => {
    expect(normalizeRoute('/index')).toBe('/');
  });
});

// ============================================================================
// TESTS: getRouteGroup
// ============================================================================

describe('getRouteGroup', () => {
  it('retourne auth pour les routes auth', () => {
    expect(getRouteGroup('/(auth)/login')).toBe('auth');
    expect(getRouteGroup('/(auth)/signup')).toBe('auth');
  });

  it('retourne tabs pour les routes tabs', () => {
    expect(getRouteGroup('/(tabs)/home')).toBe('tabs');
    expect(getRouteGroup('/(tabs)/profile')).toBe('tabs');
  });

  it('retourne onboarding pour les routes onboarding', () => {
    expect(getRouteGroup('/onboarding')).toBe('onboarding');
    expect(getRouteGroup('/onboarding/profile-setup')).toBe('onboarding');
  });

  it('retourne other pour les autres routes', () => {
    expect(getRouteGroup('/settings')).toBe('other');
    expect(getRouteGroup('/natal-chart')).toBe('other');
  });
});

// ============================================================================
// TESTS: hasNavigationStateChanged
// ============================================================================

describe('hasNavigationStateChanged', () => {
  it('retourne false si états identiques', () => {
    const state1 = createState();
    const state2 = createState();
    expect(hasNavigationStateChanged(state1, state2)).toBe(false);
  });

  it('retourne true si isAuthenticated change', () => {
    const state1 = createState({ isAuthenticated: false });
    const state2 = createState({ isAuthenticated: true });
    expect(hasNavigationStateChanged(state1, state2)).toBe(true);
  });

  it('retourne true si hasCompletedOnboarding change', () => {
    const state1 = createState({ hasCompletedOnboarding: false });
    const state2 = createState({ hasCompletedOnboarding: true });
    expect(hasNavigationStateChanged(state1, state2)).toBe(true);
  });

  it('retourne true si hasValidProfile change', () => {
    const state1 = createState({ hasValidProfile: false });
    const state2 = createState({ hasValidProfile: true });
    expect(hasNavigationStateChanged(state1, state2)).toBe(true);
  });

  it('retourne true si hasCycleSetup change', () => {
    const state1 = createState({ hasCycleSetup: false });
    const state2 = createState({ hasCycleSetup: true });
    expect(hasNavigationStateChanged(state1, state2)).toBe(true);
  });

  it('retourne true si isInitializing change', () => {
    const state1 = createState({ isInitializing: true });
    const state2 = createState({ isInitializing: false });
    expect(hasNavigationStateChanged(state1, state2)).toBe(true);
  });
});

// ============================================================================
// TESTS: createDefaultNavigationState
// ============================================================================

describe('createDefaultNavigationState', () => {
  it('crée un état par défaut correct', () => {
    const state = createDefaultNavigationState();
    
    expect(state.isAuthenticated).toBe(false);
    expect(state.hasCompletedOnboarding).toBe(false);
    expect(state.hasValidProfile).toBe(false);
    expect(state.hasCycleSetup).toBe(false);
    expect(state.isInitializing).toBe(true);
  });
});

// ============================================================================
// TESTS D'INTÉGRATION: Scénarios complets
// ============================================================================

describe('Scénarios de navigation complets', () => {
  beforeEach(() => {
    resetRoutingGuard();
  });

  it('Scénario: Nouvel utilisateur - Login → Onboarding → Profile → Cycle → Home', () => {
    // Étape 1: Non authentifié
    let state = createState();
    expect(determineRoute(state)).toBe('/(auth)/login');
    
    // Étape 2: Après login
    state = createState({ isAuthenticated: true });
    expect(determineRoute(state)).toBe('/onboarding');
    
    // Étape 3: Après welcome
    state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
    });
    expect(determineRoute(state)).toBe('/onboarding/profile-setup');
    
    // Étape 4: Après profile
    state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
    });
    expect(determineRoute(state)).toBe('/onboarding/cycle-setup');
    
    // Étape 5: Tout complété
    state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: true,
    });
    expect(determineRoute(state)).toBe('/(tabs)/home');
  });

  it('Scénario: Logout → Retour login', () => {
    // Utilisateur connecté
    let state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: true,
    });
    expect(determineRoute(state)).toBe('/(tabs)/home');
    
    // Après logout
    state = createState({ isAuthenticated: false });
    expect(determineRoute(state)).toBe('/(auth)/login');
  });

  it('Scénario: Utilisateur existant qui revient', () => {
    // Session restaurée avec tout complet
    const state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: true,
    });
    
    // Doit aller directement à home
    expect(determineRoute(state)).toBe('/(tabs)/home');
  });

  it('Scénario: Utilisateur avec profil partiel', () => {
    // A fait l'onboarding mais profil incomplet
    const state = createState({
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: false,
    });
    
    // Doit retourner au setup profil
    expect(determineRoute(state)).toBe('/onboarding/profile-setup');
  });
});

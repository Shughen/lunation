/**
 * LUNA - Cycle & Cosmos
 * Theme Colors - Couleurs de l'application
 * 
 * @version 1.0.0
 */

export const colors = {
  // Couleurs principales
  primary: '#9D4EDD',
  primaryLight: '#C77DFF',
  primaryDark: '#7B2CBF',
  
  // Couleurs secondaires
  secondary: '#E0AAFF',
  accent: '#FF6B6B',
  
  // Fonds
  background: '#10002B',
  backgroundSecondary: '#240046',
  backgroundTertiary: '#3C096C',
  
  // Texte
  text: '#FFFFFF',
  textSecondary: '#A0A0A0',
  textMuted: '#666666',
  
  // États
  success: '#4CAF50',
  warning: '#FFC107',
  error: '#F44336',
  info: '#2196F3',
  
  // Bordures
  border: '#3C096C',
  borderLight: '#5A189A',
  
  // Overlay
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
  
  // Phases du cycle (pour le calendrier)
  phases: {
    menstruation: '#FF6B6B',
    follicular: '#4ECDC4',
    ovulation: '#FFE66D',
    luteal: '#95E1D3',
  },
  
  // Lune
  moon: {
    new: '#1A1A2E',
    waxingCrescent: '#3D3D5C',
    firstQuarter: '#5A5A8A',
    waxingGibbous: '#8888BB',
    full: '#FFFFEE',
    waningGibbous: '#CCCCDD',
    lastQuarter: '#9999BB',
    waningCrescent: '#666688',
  },
} as const;

export type ColorKey = keyof typeof colors;
export type PhaseColor = keyof typeof colors.phases;
export type MoonColor = keyof typeof colors.moon;

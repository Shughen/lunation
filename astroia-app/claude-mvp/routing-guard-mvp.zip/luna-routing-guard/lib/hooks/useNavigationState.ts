/**
 * LUNA - Cycle & Cosmos
 * useNavigationState - Hook centralisé pour l'état de navigation
 * 
 * Ce hook compose les différents stores (auth, profile, onboarding)
 * pour produire un état de navigation unifié utilisé par le routing guard.
 * 
 * @version 1.0.0
 * @date 27 novembre 2025
 */

import { useMemo, useEffect, useState, useCallback } from 'react';
import { useAuthStore } from '@/stores/authStore';
import { useProfileStore } from '@/stores/profileStore';
import type { NavigationState, MinimalProfile } from '@/lib/navigation/navigationTypes';

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Vérifie si un profil contient toutes les informations requises.
 * Un profil est considéré "valide" s'il a les données de naissance complètes.
 */
export function isProfileComplete(profile: MinimalProfile | null): boolean {
  if (!profile) return false;
  
  return !!(
    profile.name &&
    profile.name.trim().length > 0 &&
    profile.birth_date &&
    profile.birth_time &&
    profile.birth_location &&
    // Coordonnées optionnelles mais recommandées
    // On ne bloque pas si manquantes car peuvent être calculées
    true
  );
}

/**
 * Vérifie si le cycle menstruel est configuré.
 * Nécessite les dernières règles ET la durée du cycle.
 */
export function isCycleConfigured(profile: MinimalProfile | null): boolean {
  if (!profile) return false;
  
  return !!(
    profile.last_period &&
    profile.cycle_length &&
    profile.cycle_length >= 21 && // Cycle minimum physiologique
    profile.cycle_length <= 45    // Cycle maximum physiologique
  );
}

// ============================================================================
// HOOK PRINCIPAL
// ============================================================================

/**
 * Hook principal qui retourne l'état de navigation calculé.
 * 
 * @returns NavigationState - État unifié pour le routing guard
 * 
 * @example
 * function RootLayout() {
 *   const navigationState = useNavigationState();
 *   const targetRoute = determineRoute(navigationState);
 *   
 *   useEffect(() => {
 *     if (!navigationState.isInitializing && router.pathname !== targetRoute) {
 *       router.replace(targetRoute);
 *     }
 *   }, [targetRoute, navigationState.isInitializing]);
 * }
 */
export function useNavigationState(): NavigationState {
  // =========================================================================
  // STORES
  // =========================================================================
  
  // Auth store
  const session = useAuthStore((state) => state.session);
  const isAuthInitialized = useAuthStore((state) => state.isInitialized);
  const onboardingCompleted = useAuthStore((state) => state.onboardingCompleted);
  
  // Profile store
  const profile = useProfileStore((state) => state.profile);
  const isProfileLoading = useProfileStore((state) => state.isLoading);
  
  // =========================================================================
  // DERIVED STATE
  // =========================================================================
  
  const navigationState = useMemo<NavigationState>(() => {
    // L'app est en initialisation si:
    // - Auth pas encore initialisé
    // - Ou si authentifié mais profil en cours de chargement
    const isInitializing = !isAuthInitialized || 
      (!!session && isProfileLoading);
    
    // Authentifié si session Supabase existe
    const isAuthenticated = !!session;
    
    // Onboarding complété si flag set dans auth store
    // Ce flag est persisté dans AsyncStorage
    const hasCompletedOnboarding = onboardingCompleted === true;
    
    // Profil valide si toutes les infos de naissance sont présentes
    const hasValidProfile = isProfileComplete(profile as MinimalProfile | null);
    
    // Cycle configuré si dernières règles et durée définies
    const hasCycleSetup = isCycleConfigured(profile as MinimalProfile | null);
    
    return {
      isAuthenticated,
      hasCompletedOnboarding,
      hasValidProfile,
      hasCycleSetup,
      isInitializing,
    };
  }, [session, isAuthInitialized, onboardingCompleted, profile, isProfileLoading]);
  
  // =========================================================================
  // DEBUG
  // =========================================================================
  
  useEffect(() => {
    if (__DEV__) {
      console.log('[useNavigationState] State changed:', {
        isAuthenticated: navigationState.isAuthenticated,
        hasCompletedOnboarding: navigationState.hasCompletedOnboarding,
        hasValidProfile: navigationState.hasValidProfile,
        hasCycleSetup: navigationState.hasCycleSetup,
        isInitializing: navigationState.isInitializing,
      });
    }
  }, [navigationState]);
  
  return navigationState;
}

// ============================================================================
// HOOKS AUXILIAIRES
// ============================================================================

/**
 * Hook pour savoir si l'app est prête pour la navigation.
 * Utile pour afficher un splash screen pendant l'initialisation.
 */
export function useIsAppReady(): boolean {
  const { isInitializing } = useNavigationState();
  const [isReady, setIsReady] = useState(false);
  
  useEffect(() => {
    if (!isInitializing) {
      // Petit délai pour éviter flash
      const timer = setTimeout(() => {
        setIsReady(true);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isInitializing]);
  
  return isReady;
}

/**
 * Hook pour obtenir le prochain step d'onboarding requis.
 * Retourne null si l'onboarding est complet.
 */
export function useOnboardingNextStep(): string | null {
  const { hasCompletedOnboarding, hasValidProfile, hasCycleSetup } = useNavigationState();
  
  if (!hasCompletedOnboarding) return '/onboarding';
  if (!hasValidProfile) return '/onboarding/profile-setup';
  if (!hasCycleSetup) return '/onboarding/cycle-setup';
  return null;
}

/**
 * Hook pour vérifier si l'utilisateur peut accéder aux features principales.
 */
export function useCanAccessMainFeatures(): boolean {
  const { isAuthenticated, hasCompletedOnboarding, hasValidProfile, hasCycleSetup } = useNavigationState();
  
  return isAuthenticated && hasCompletedOnboarding && hasValidProfile && hasCycleSetup;
}

/**
 * Hook pour obtenir un résumé de l'état de setup.
 * Utile pour afficher une progress bar dans l'onboarding.
 */
export function useSetupProgress(): {
  currentStep: number;
  totalSteps: number;
  percentage: number;
  steps: Array<{ name: string; completed: boolean }>;
} {
  const state = useNavigationState();
  
  const steps = [
    { name: 'Authentification', completed: state.isAuthenticated },
    { name: 'Bienvenue', completed: state.hasCompletedOnboarding },
    { name: 'Profil', completed: state.hasValidProfile },
    { name: 'Cycle', completed: state.hasCycleSetup },
  ];
  
  const completedCount = steps.filter(s => s.completed).length;
  
  return {
    currentStep: completedCount,
    totalSteps: steps.length,
    percentage: Math.round((completedCount / steps.length) * 100),
    steps,
  };
}

// ============================================================================
// UTILITIES POUR TESTS
// ============================================================================

/**
 * Crée un état de navigation mock pour les tests.
 */
export function createMockNavigationState(
  overrides: Partial<NavigationState> = {}
): NavigationState {
  return {
    isAuthenticated: false,
    hasCompletedOnboarding: false,
    hasValidProfile: false,
    hasCycleSetup: false,
    isInitializing: false,
    ...overrides,
  };
}

// Export default du hook principal
export default useNavigationState;

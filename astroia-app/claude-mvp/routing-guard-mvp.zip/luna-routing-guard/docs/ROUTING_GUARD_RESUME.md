# 🧭 ROUTING GUARD - Documentation

**Date :** 27 novembre 2025  
**Version :** 1.0.0  
**Projet :** LUNA - Cycle & Cosmos

---

## 📋 Table des matières

1. [Principe](#principe)
2. [Architecture](#architecture)
3. [Fichiers créés](#fichiers-créés)
4. [Comment ça marche](#comment-ça-marche)
5. [API Reference](#api-reference)
6. [Tests](#tests)
7. [Migration depuis l'ancien système](#migration)
8. [Troubleshooting](#troubleshooting)

---

## 🎯 Principe

Le **Routing Guard** est un système centralisé qui gère **toute la logique de navigation** de l'application LUNA. 

### Problème résolu

Avant cette refonte, la logique de routing était dispersée dans 5 fichiers différents :
- `app/_layout.js`
- `app/(auth)/_layout.js`
- `app/(tabs)/_layout.js`
- `app/onboarding/_layout.js`
- `app/index.js`

Cela causait :
- ❌ Boucles infinies de redirection
- ❌ Navigation imprévisible
- ❌ Code spaghetti non maintenable
- ❌ Flash d'écrans pendant les transitions

### Solution

**Une seule source de vérité** : le fichier `routingGuard.ts` contient TOUTE la logique de décision.

```
┌─────────────────────────────────────────────────────────────┐
│                        app/_layout.js                        │
│                    (SEUL fichier avec routing)               │
│                              │                               │
│                              ▼                               │
│                    useNavigationState()                      │
│                              │                               │
│                              ▼                               │
│                    determineRoute(state)                     │
│                              │                               │
│           ┌─────────────────┼─────────────────┐             │
│           ▼                 ▼                 ▼             │
│      /(auth)/login    /onboarding      /(tabs)/home         │
└─────────────────────────────────────────────────────────────┘
```

---

## 🏗️ Architecture

### Flow de décision

```typescript
function determineRoute(state: NavigationState): AppRoute {
  // 1. Non authentifié → Login
  if (!state.isAuthenticated) return '/(auth)/login';
  
  // 2. Onboarding non fait → Onboarding
  if (!state.hasCompletedOnboarding) return '/onboarding';
  
  // 3. Profil incomplet → Profile setup
  if (!state.hasValidProfile) return '/onboarding/profile-setup';
  
  // 4. Cycle non configuré → Cycle setup
  if (!state.hasCycleSetup) return '/onboarding/cycle-setup';
  
  // 5. Tout OK → Home
  return '/(tabs)/home';
}
```

### État de navigation

```typescript
interface NavigationState {
  isAuthenticated: boolean;      // Session Supabase active
  hasCompletedOnboarding: boolean; // Welcome screen vu
  hasValidProfile: boolean;       // Nom + date/heure/lieu naissance
  hasCycleSetup: boolean;         // Dernières règles + durée cycle
  isInitializing: boolean;        // App en cours de chargement
}
```

---

## 📁 Fichiers créés

### Nouveaux fichiers

```
lib/navigation/
├── index.ts              # Exports centralisés
├── navigationTypes.ts    # Types et interfaces
├── routingGuard.ts       # Logique de routing
└── __tests__/
    └── routingGuard.test.ts  # Tests unitaires (40+ tests)

lib/hooks/
└── useNavigationState.ts # Hook composant les stores

__tests__/e2e/
└── navigation-flow.test.ts # Tests E2E navigation
```

### Fichiers modifiés

```
app/_layout.js           # ✅ Utilise maintenant le routing guard
app/(auth)/_layout.js    # ✅ Supprimé toute logique routing
app/(tabs)/_layout.js    # ✅ Supprimé toute logique routing
app/onboarding/_layout.js # ✅ Supprimé toute logique routing
app/index.js             # ✅ Simplifié (délègue au guard)
```

---

## ⚙️ Comment ça marche

### 1. Hook `useNavigationState`

Ce hook lit les stores et produit un état unifié :

```typescript
function useNavigationState(): NavigationState {
  const session = useAuthStore((s) => s.session);
  const profile = useProfileStore((s) => s.profile);
  const onboarding = useAuthStore((s) => s.onboardingCompleted);
  
  return useMemo(() => ({
    isAuthenticated: !!session,
    hasCompletedOnboarding: onboarding === true,
    hasValidProfile: isProfileComplete(profile),
    hasCycleSetup: isCycleConfigured(profile),
    isInitializing: !isAuthInitialized || isProfileLoading,
  }), [session, profile, onboarding]);
}
```

### 2. RootLayout utilise le guard

```typescript
// app/_layout.js
export default function RootLayout() {
  const navigationState = useNavigationState();
  const targetRoute = determineRoute(navigationState);
  
  useEffect(() => {
    if (!navigationState.isInitializing) {
      if (shouldRedirect(pathname, targetRoute)) {
        router.replace(targetRoute);
      }
    }
  }, [navigationState, pathname]);
  
  return <Stack>...</Stack>;
}
```

### 3. Layouts enfants sont "dumb"

```typescript
// app/(auth)/_layout.js
export default function AuthLayout() {
  // ⚠️ AUCUNE logique de routing ici !
  return <Stack>...</Stack>;
}
```

---

## 📖 API Reference

### `determineRoute(state: NavigationState): AppRoute`

Calcule la route cible selon l'état.

```typescript
const state = useNavigationState();
const route = determineRoute(state);
// '/(auth)/login' | '/onboarding' | '/(tabs)/home' | etc.
```

### `validateTransition(from, to, state): TransitionValidationResult`

Vérifie si une transition est autorisée.

```typescript
const result = validateTransition('/onboarding', '/(tabs)/home', state);
if (!result.isValid) {
  console.log('Blocked:', result.reason);
  console.log('Redirect to:', result.suggestedRoute);
}
```

### `shouldRedirect(current, target, options?): boolean`

Vérifie si une redirection doit être effectuée (avec protection anti-boucle).

```typescript
if (shouldRedirect(pathname, targetRoute, { debug: true })) {
  router.replace(targetRoute);
}
```

### `isPublicRoute(route): boolean`

Vérifie si une route est publique.

```typescript
isPublicRoute('/(auth)/login'); // true
isPublicRoute('/(tabs)/home');  // false
```

### `resetRoutingGuard(): void`

Réinitialise l'état interne (utile après logout ou pour tests).

```typescript
// Après logout
await logout();
resetRoutingGuard();
```

---

## 🧪 Tests

### Lancer les tests unitaires

```bash
# Tous les tests
npm test

# Tests routing guard uniquement
npm test -- routingGuard.test.ts

# Avec coverage
npm test -- --coverage
```

### Lancer les tests E2E

```bash
# Tests E2E navigation
npm test -- navigation-flow.test.ts
```

### Cas de test couverts

1. **Non authentifié** → Redirige vers login
2. **Authentifié sans onboarding** → Redirige vers onboarding
3. **Onboarding fait sans profil** → Redirige vers profile-setup
4. **Profil OK sans cycle** → Redirige vers cycle-setup
5. **Tout complété** → Redirige vers home
6. **Logout** → Retour login
7. **Protection anti-boucle** → Bloque après 5 redirections
8. **Transitions autorisées/bloquées**
9. **Fuite données entre users** → Vérifie isolation

---

## 🔄 Migration

### Avant/Après

**AVANT (❌ À SUPPRIMER):**

```javascript
// app/(auth)/_layout.js
useEffect(() => {
  if (session) {
    router.replace('/(tabs)/home'); // ❌
  }
}, [session]);
```

**APRÈS (✅ CLEAN):**

```javascript
// app/(auth)/_layout.js
export default function AuthLayout() {
  // Aucune logique !
  return <Stack>...</Stack>;
}
```

### Checklist migration

- [x] Créer `lib/navigation/routingGuard.ts`
- [x] Créer `lib/hooks/useNavigationState.ts`
- [x] Modifier `app/_layout.js` pour utiliser le guard
- [x] Supprimer redirections de `app/(auth)/_layout.js`
- [x] Supprimer redirections de `app/(tabs)/_layout.js`
- [x] Supprimer redirections de `app/onboarding/_layout.js`
- [x] Simplifier `app/index.js`
- [x] Ajouter tests unitaires
- [x] Ajouter tests E2E

---

## 🔧 Troubleshooting

### Boucle infinie détectée

**Symptôme:** L'app redirige en boucle, console affiche "[RoutingGuard] Too many redirects"

**Cause:** Probablement un état incohérent entre stores.

**Solution:**
```typescript
import { resetRoutingGuard } from '@/lib/navigation';

// Appeler après logout ou quand nécessaire
resetRoutingGuard();
```

### Navigation ne fonctionne pas

**Symptôme:** Cliquer sur un tab ne change pas d'écran.

**Vérifier:**
1. L'état `isInitializing` est-il false ?
2. `determineRoute()` retourne-t-il la bonne route ?
3. Les logs console montrent-ils des erreurs ?

**Debug:**
```typescript
// Dans le composant
console.log('[Debug]', {
  state: useNavigationState(),
  target: determineRoute(useNavigationState()),
  current: pathname,
});
```

### Écran flash pendant transition

**Symptôme:** Écran blanc ou flash pendant navigation.

**Solution:** Vérifier que `isInitializing` est géré :

```typescript
if (navigationState.isInitializing) {
  return <LoadingScreen />;
}
```

---

## 📞 Support

Si vous rencontrez des problèmes :

1. Vérifier les logs console (`[RoutingGuard]`)
2. Lancer les tests pour détecter les régressions
3. Vérifier que les stores retournent les bonnes valeurs

---

**Documentation créée le 27 novembre 2025**

/**
 * LUNA - Cycle & Cosmos
 * Tests E2E - Flow de navigation
 * 
 * Ces tests vérifient le flow complet de navigation de l'application.
 * Utilise React Native Testing Library pour simuler les interactions.
 * 
 * @version 1.0.0
 * @date 27 novembre 2025
 */

import React from 'react';
import { render, waitFor, fireEvent, act } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';

// Mocks
jest.mock('@/stores/authStore');
jest.mock('@/stores/profileStore');
jest.mock('expo-router', () => ({
  useRouter: jest.fn(() => ({
    replace: jest.fn(),
    push: jest.fn(),
    back: jest.fn(),
  })),
  usePathname: jest.fn(() => '/'),
  useSegments: jest.fn(() => []),
  Stack: {
    Screen: jest.fn(() => null),
  },
  Tabs: {
    Screen: jest.fn(() => null),
  },
}));

import { useAuthStore } from '@/stores/authStore';
import { useProfileStore } from '@/stores/profileStore';
import { useRouter } from 'expo-router';
import { determineRoute, resetRoutingGuard } from '@/lib/navigation/routingGuard';
import { useNavigationState } from '@/lib/hooks/useNavigationState';

// ============================================================================
// SETUP
// ============================================================================

// Mock des stores avec des états modifiables
const mockAuthState = {
  session: null,
  isInitialized: true,
  onboardingCompleted: false,
  initialize: jest.fn(),
};

const mockProfileState = {
  profile: null,
  isLoading: false,
};

beforeEach(() => {
  jest.clearAllMocks();
  resetRoutingGuard();
  
  // Reset des mocks
  (useAuthStore as jest.Mock).mockImplementation((selector) => {
    if (typeof selector === 'function') {
      return selector(mockAuthState);
    }
    return mockAuthState;
  });
  
  (useProfileStore as jest.Mock).mockImplementation((selector) => {
    if (typeof selector === 'function') {
      return selector(mockProfileState);
    }
    return mockProfileState;
  });
});

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Simule un login réussi
 */
async function simulateLogin() {
  mockAuthState.session = { user: { id: 'test-user-id' } };
  mockAuthState.isInitialized = true;
}

/**
 * Simule la complétion de l'onboarding
 */
async function simulateOnboardingComplete() {
  mockAuthState.onboardingCompleted = true;
}

/**
 * Simule un profil complet
 */
async function simulateProfileComplete() {
  mockProfileState.profile = {
    id: 'test-user-id',
    name: 'Test User',
    birth_date: '1990-01-15',
    birth_time: '14:30',
    birth_location: 'Paris, France',
    birth_latitude: 48.8566,
    birth_longitude: 2.3522,
    last_period: '2025-11-01',
    cycle_length: 28,
  };
}

/**
 * Simule un logout
 */
async function simulateLogout() {
  mockAuthState.session = null;
  mockAuthState.onboardingCompleted = false;
  mockProfileState.profile = null;
}

/**
 * Composant de test simple qui utilise le hook
 */
function TestNavigationComponent() {
  const state = useNavigationState();
  const targetRoute = determineRoute(state);
  
  return (
    <NavigationContainer>
      {/* Affiche l'état pour les tests */}
      {JSON.stringify({ state, targetRoute })}
    </NavigationContainer>
  );
}

// ============================================================================
// TESTS E2E: Flow d'authentification complet
// ============================================================================

describe('Navigation Flow E2E', () => {
  describe('Flow: Non authentifié → Login', () => {
    it('redirige vers login quand non authentifié', async () => {
      // État initial: non authentifié
      mockAuthState.session = null;
      
      const { getByText } = render(<TestNavigationComponent />);
      
      await waitFor(() => {
        const content = getByText(/"targetRoute":"\/\(auth\)\/login"/);
        expect(content).toBeTruthy();
      });
    });
  });

  describe('Flow: Login → Onboarding → Home', () => {
    it('suit le flow complet après login', async () => {
      const mockRouter = {
        replace: jest.fn(),
        push: jest.fn(),
        back: jest.fn(),
      };
      (useRouter as jest.Mock).mockReturnValue(mockRouter);

      // Étape 1: Non authentifié → Login
      mockAuthState.session = null;
      let targetRoute = determineRoute({
        isAuthenticated: false,
        hasCompletedOnboarding: false,
        hasValidProfile: false,
        hasCycleSetup: false,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/(auth)/login');

      // Étape 2: Après login → Onboarding
      await simulateLogin();
      targetRoute = determineRoute({
        isAuthenticated: true,
        hasCompletedOnboarding: false,
        hasValidProfile: false,
        hasCycleSetup: false,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/onboarding');

      // Étape 3: Après welcome → Profile setup
      await simulateOnboardingComplete();
      targetRoute = determineRoute({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: false,
        hasCycleSetup: false,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/onboarding/profile-setup');

      // Étape 4: Après profile → Cycle setup
      mockProfileState.profile = {
        id: 'test',
        name: 'Test',
        birth_date: '1990-01-01',
        birth_time: '12:00',
        birth_location: 'Paris',
      };
      targetRoute = determineRoute({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: false,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/onboarding/cycle-setup');

      // Étape 5: Tout complété → Home
      await simulateProfileComplete();
      targetRoute = determineRoute({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: true,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/(tabs)/home');
    });
  });

  describe('Flow: Logout → Retour login', () => {
    it('redirige vers login après logout', async () => {
      // Setup: utilisateur connecté et configuré
      await simulateLogin();
      await simulateOnboardingComplete();
      await simulateProfileComplete();

      // Vérifier qu'on est sur home
      let targetRoute = determineRoute({
        isAuthenticated: true,
        hasCompletedOnboarding: true,
        hasValidProfile: true,
        hasCycleSetup: true,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/(tabs)/home');

      // Simuler logout
      await simulateLogout();

      // Vérifier redirection vers login
      targetRoute = determineRoute({
        isAuthenticated: false,
        hasCompletedOnboarding: false,
        hasValidProfile: false,
        hasCycleSetup: false,
        isInitializing: false,
      });
      expect(targetRoute).toBe('/(auth)/login');
    });

    it('nettoie les données utilisateur après logout', async () => {
      // Setup utilisateur A
      await simulateLogin();
      await simulateProfileComplete();
      
      // Vérifier que le profil existe
      expect(mockProfileState.profile).not.toBeNull();
      expect(mockProfileState.profile?.name).toBe('Test User');

      // Logout
      await simulateLogout();

      // Vérifier que le profil est nettoyé
      expect(mockProfileState.profile).toBeNull();
      expect(mockAuthState.session).toBeNull();
    });
  });
});

// ============================================================================
// TESTS E2E: Sécurité des données entre utilisateurs
// ============================================================================

describe('Sécurité données multi-utilisateurs', () => {
  it('ne fuite pas les données entre utilisateurs', async () => {
    // Login utilisateur A
    mockAuthState.session = { user: { id: 'user-A' } };
    mockProfileState.profile = {
      id: 'user-A',
      name: 'Alice',
      birth_date: '1990-01-01',
      birth_time: '12:00',
      birth_location: 'Paris',
      last_period: '2025-11-01',
      cycle_length: 28,
    };

    const profileA = mockProfileState.profile;
    expect(profileA?.name).toBe('Alice');

    // Logout
    await simulateLogout();

    // Vérifier que les données sont nettoyées
    expect(mockProfileState.profile).toBeNull();

    // Login utilisateur B
    mockAuthState.session = { user: { id: 'user-B' } };
    mockProfileState.profile = {
      id: 'user-B',
      name: 'Bob',
      birth_date: '1985-05-15',
      birth_time: '09:30',
      birth_location: 'Lyon',
      last_period: '2025-11-05',
      cycle_length: 30,
    };

    const profileB = mockProfileState.profile;

    // Vérifier que c'est bien un utilisateur différent
    expect(profileB?.id).not.toBe(profileA?.id);
    expect(profileB?.name).toBe('Bob');
    expect(profileB?.name).not.toBe('Alice');
  });
});

// ============================================================================
// TESTS E2E: États d'initialisation
// ============================================================================

describe('États d\'initialisation', () => {
  it('affiche un loader pendant l\'initialisation', async () => {
    // Simuler état d'initialisation
    mockAuthState.isInitialized = false;

    const state = {
      isAuthenticated: false,
      hasCompletedOnboarding: false,
      hasValidProfile: false,
      hasCycleSetup: false,
      isInitializing: true,
    };

    // Pendant l'init, la route déterminée devrait quand même être login
    // mais le composant parent doit gérer l'affichage du loader
    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/(auth)/login');
  });

  it('cache le loader après initialisation', async () => {
    // Initialisation terminée
    mockAuthState.isInitialized = true;
    mockAuthState.session = null;

    const state = {
      isAuthenticated: false,
      hasCompletedOnboarding: false,
      hasValidProfile: false,
      hasCycleSetup: false,
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/(auth)/login');
  });
});

// ============================================================================
// TESTS E2E: Navigation protégée
// ============================================================================

describe('Navigation protégée', () => {
  it('empêche l\'accès à home sans authentification', () => {
    const state = {
      isAuthenticated: false,
      hasCompletedOnboarding: false,
      hasValidProfile: false,
      hasCycleSetup: false,
      isInitializing: false,
    };

    // Même si on essaie d'aller à home, on doit être redirigé
    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/(auth)/login');
    expect(targetRoute).not.toBe('/(tabs)/home');
  });

  it('empêche l\'accès à home sans onboarding complété', () => {
    const state = {
      isAuthenticated: true,
      hasCompletedOnboarding: false,
      hasValidProfile: false,
      hasCycleSetup: false,
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/onboarding');
    expect(targetRoute).not.toBe('/(tabs)/home');
  });

  it('empêche l\'accès à home sans profil complété', () => {
    const state = {
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: false,
      hasCycleSetup: false,
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/onboarding/profile-setup');
    expect(targetRoute).not.toBe('/(tabs)/home');
  });

  it('empêche l\'accès à home sans cycle configuré', () => {
    const state = {
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: false,
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/onboarding/cycle-setup');
    expect(targetRoute).not.toBe('/(tabs)/home');
  });
});

// ============================================================================
// TESTS E2E: Cas limites
// ============================================================================

describe('Cas limites', () => {
  it('gère une session expirée', async () => {
    // Utilisateur connecté
    await simulateLogin();
    await simulateOnboardingComplete();
    await simulateProfileComplete();

    // Session expire (simulé par null)
    mockAuthState.session = null;

    const state = {
      isAuthenticated: false,
      hasCompletedOnboarding: true, // Toujours true en local
      hasValidProfile: true,
      hasCycleSetup: true,
      isInitializing: false,
    };

    // Doit rediriger vers login malgré les autres flags
    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/(auth)/login');
  });

  it('gère un profil partiellement complété', () => {
    mockProfileState.profile = {
      id: 'test',
      name: 'Test',
      birth_date: '1990-01-01',
      // Manque birth_time et birth_location
    };

    const state = {
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: false, // Car profil incomplet
      hasCycleSetup: false,
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/onboarding/profile-setup');
  });

  it('gère un cycle avec valeurs invalides', () => {
    mockProfileState.profile = {
      id: 'test',
      name: 'Test',
      birth_date: '1990-01-01',
      birth_time: '12:00',
      birth_location: 'Paris',
      last_period: '2025-11-01',
      cycle_length: 10, // Invalide: < 21
    };

    const state = {
      isAuthenticated: true,
      hasCompletedOnboarding: true,
      hasValidProfile: true,
      hasCycleSetup: false, // Car cycle_length invalide
      isInitializing: false,
    };

    const targetRoute = determineRoute(state);
    expect(targetRoute).toBe('/onboarding/cycle-setup');
  });
});

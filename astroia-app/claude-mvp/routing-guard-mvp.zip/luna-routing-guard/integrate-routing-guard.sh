#!/bin/bash
# LUNA - Cycle & Cosmos
# Script d'intégration du Routing Guard
# 
# Ce script aide à intégrer les fichiers du routing guard dans votre repo.
# 
# Usage: ./integrate-routing-guard.sh /path/to/your/repo
#
# Date: 27 novembre 2025

set -e

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Vérifier argument
if [ -z "$1" ]; then
    echo -e "${RED}Usage: $0 /path/to/your/repo${NC}"
    exit 1
fi

REPO_PATH="$1"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BLUE}======================================${NC}"
echo -e "${BLUE}  LUNA - Routing Guard Integration   ${NC}"
echo -e "${BLUE}======================================${NC}"
echo ""

# Vérifier que le repo existe
if [ ! -d "$REPO_PATH" ]; then
    echo -e "${RED}Error: Directory $REPO_PATH does not exist${NC}"
    exit 1
fi

# Vérifier que c'est un repo git
if [ ! -d "$REPO_PATH/.git" ]; then
    echo -e "${RED}Error: $REPO_PATH is not a git repository${NC}"
    exit 1
fi

cd "$REPO_PATH"

echo -e "${YELLOW}Step 1: Checking current branch...${NC}"
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
echo "Current branch: $CURRENT_BRANCH"

echo ""
echo -e "${YELLOW}Step 2: Creating new branch...${NC}"
git checkout -b feat/routing-guard-mvp || {
    echo -e "${YELLOW}Branch exists, switching to it...${NC}"
    git checkout feat/routing-guard-mvp
}

echo ""
echo -e "${YELLOW}Step 3: Creating directories...${NC}"
mkdir -p lib/navigation
mkdir -p lib/navigation/__tests__
mkdir -p lib/hooks
mkdir -p lib/theme
mkdir -p __tests__/e2e
mkdir -p stores/__mocks__
mkdir -p docs

echo -e "${GREEN}Directories created!${NC}"

echo ""
echo -e "${YELLOW}Step 4: Copying files...${NC}"

# Liste des fichiers à copier
FILES=(
    "lib/navigation/navigationTypes.ts"
    "lib/navigation/routingGuard.ts"
    "lib/navigation/index.ts"
    "lib/navigation/__tests__/routingGuard.test.ts"
    "lib/hooks/useNavigationState.ts"
    "lib/theme/colors.ts"
    "__tests__/e2e/navigation-flow.test.ts"
    "stores/__mocks__/authStore.ts"
    "stores/__mocks__/profileStore.ts"
    "jest.config.js"
    "jest.setup.js"
    "docs/ROUTING_GUARD_RESUME.md"
)

for file in "${FILES[@]}"; do
    if [ -f "$SCRIPT_DIR/$file" ]; then
        cp "$SCRIPT_DIR/$file" "$REPO_PATH/$file"
        echo -e "  ${GREEN}✓${NC} $file"
    else
        echo -e "  ${YELLOW}⚠${NC} $file (not found in source)"
    fi
done

echo ""
echo -e "${YELLOW}Step 5: Backup and update layouts...${NC}"

# Backup des layouts existants
LAYOUTS=(
    "app/_layout.js"
    "app/(auth)/_layout.js"
    "app/(tabs)/_layout.js"
    "app/onboarding/_layout.js"
    "app/index.js"
)

for layout in "${LAYOUTS[@]}"; do
    if [ -f "$REPO_PATH/$layout" ]; then
        cp "$REPO_PATH/$layout" "$REPO_PATH/$layout.backup"
        echo -e "  ${GREEN}✓${NC} Backed up $layout"
    fi
done

# Copier les nouveaux layouts
for layout in "${LAYOUTS[@]}"; do
    if [ -f "$SCRIPT_DIR/$layout" ]; then
        cp "$SCRIPT_DIR/$layout" "$REPO_PATH/$layout"
        echo -e "  ${GREEN}✓${NC} Updated $layout"
    fi
done

echo ""
echo -e "${YELLOW}Step 6: Verifying .env files are not modified...${NC}"
# Vérifier que .env n'est pas dans les changements
if git status --porcelain | grep -q "\.env"; then
    echo -e "${RED}Warning: .env file is in the changes!${NC}"
    git checkout -- .env* 2>/dev/null || true
else
    echo -e "${GREEN}✓ No .env files modified${NC}"
fi

echo ""
echo -e "${YELLOW}Step 7: Git status...${NC}"
git status

echo ""
echo -e "${BLUE}======================================${NC}"
echo -e "${BLUE}         Integration Complete!        ${NC}"
echo -e "${BLUE}======================================${NC}"
echo ""
echo -e "Next steps:"
echo ""
echo -e "  1. ${YELLOW}Review changes:${NC}"
echo -e "     git diff"
echo ""
echo -e "  2. ${YELLOW}Run tests:${NC}"
echo -e "     npm test -- routingGuard.test.ts"
echo -e "     npm test -- navigation-flow.test.ts"
echo ""
echo -e "  3. ${YELLOW}Start the app:${NC}"
echo -e "     npx expo start"
echo ""
echo -e "  4. ${YELLOW}If everything works, commit:${NC}"
echo -e "     git add ."
echo -e "     git commit -m \"feat: routing guard centralisé + navigation déterministe\""
echo ""
echo -e "  5. ${YELLOW}Push the branch:${NC}"
echo -e "     git push -u origin feat/routing-guard-mvp"
echo ""
echo -e "${GREEN}Good luck! 🚀${NC}"

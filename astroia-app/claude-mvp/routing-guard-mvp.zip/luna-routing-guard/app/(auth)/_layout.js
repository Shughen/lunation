/**
 * LUNA - Cycle & Cosmos
 * Auth Layout - Layout pour les écrans d'authentification
 * 
 * ⚠️ IMPORTANT: Ce layout NE DOIT PAS contenir de logique de routing.
 * Toute la logique de navigation est gérée par le RootLayout via le routing guard.
 * 
 * @version 2.0.0 (refactored - suppression redirections)
 * @date 27 novembre 2025
 */

import { Stack } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';

// Theme
import { colors } from '@/lib/theme/colors';

// ============================================================================
// COMPOSANT
// ============================================================================

export default function AuthLayout() {
  // =========================================================================
  // ⚠️ AUCUNE LOGIQUE DE ROUTING ICI
  // =========================================================================
  // 
  // AVANT (❌ SUPPRIMÉ):
  // const session = useAuthStore((s) => s.session);
  // useEffect(() => {
  //   if (session) {
  //     router.replace('/(tabs)/home');
  //   }
  // }, [session]);
  //
  // MAINTENANT: Toute la logique est dans app/_layout.js via routingGuard
  // =========================================================================

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
          contentStyle: {
            backgroundColor: colors.background,
          },
        }}
      >
        {/* Écran de connexion */}
        <Stack.Screen 
          name="login" 
          options={{
            title: 'Connexion',
            animation: 'fade',
          }}
        />
        
        {/* Écran d'inscription */}
        <Stack.Screen 
          name="signup" 
          options={{
            title: 'Inscription',
            animation: 'slide_from_right',
          }}
        />
        
        {/* Écran de vérification OTP */}
        <Stack.Screen 
          name="verify-otp" 
          options={{
            title: 'Vérification',
            animation: 'slide_from_right',
          }}
        />
        
        {/* Écran mot de passe oublié */}
        <Stack.Screen 
          name="forgot-password" 
          options={{
            title: 'Mot de passe oublié',
            animation: 'slide_from_right',
          }}
        />
      </Stack>
    </View>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
});

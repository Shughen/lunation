/**
 * LUNA - Cycle & Cosmos
 * Root Layout - Point d'entrée principal de l'application
 * 
 * CE FICHIER EST LE SEUL ENDROIT AVEC LA LOGIQUE DE ROUTING.
 * Tous les autres layouts doivent être "dumb" (sans redirections).
 * 
 * @version 2.0.0 (refactored)
 * @date 27 novembre 2025
 */

import { useEffect, useCallback, useRef } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { Stack, useRouter, useSegments, usePathname } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';

// Navigation
import { 
  determineRoute, 
  shouldRedirect, 
  recordRedirect,
  createTransition,
  normalizeRoute,
} from '@/lib/navigation/routingGuard';
import { useNavigationState, useIsAppReady } from '@/lib/hooks/useNavigationState';

// Stores
import { useAuthStore } from '@/stores/authStore';

// Theme
import { colors } from '@/lib/theme/colors';

// Empêcher le splash screen de se cacher automatiquement
SplashScreen.preventAutoHideAsync();

// ============================================================================
// COMPOSANT PRINCIPAL
// ============================================================================

export default function RootLayout() {
  const router = useRouter();
  const pathname = usePathname();
  const segments = useSegments();
  
  // État de navigation centralisé
  const navigationState = useNavigationState();
  const isAppReady = useIsAppReady();
  
  // Ref pour éviter les redirections multiples
  const isRedirecting = useRef(false);
  const lastRedirectTime = useRef(0);
  
  // Auth store pour initialisation
  const initializeAuth = useAuthStore((state) => state.initialize);
  const isAuthInitialized = useAuthStore((state) => state.isInitialized);
  
  // Chargement des fonts
  const [fontsLoaded] = useFonts({
    // Ajoutez vos fonts ici si nécessaire
    // 'SpaceMono': require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  // =========================================================================
  // INITIALISATION
  // =========================================================================
  
  useEffect(() => {
    // Initialiser l'auth au démarrage
    const init = async () => {
      try {
        await initializeAuth();
      } catch (error) {
        console.error('[RootLayout] Auth initialization error:', error);
      }
    };
    
    init();
  }, [initializeAuth]);

  // =========================================================================
  // SPLASH SCREEN
  // =========================================================================
  
  useEffect(() => {
    const hideSplash = async () => {
      if (fontsLoaded && isAuthInitialized) {
        // Attendre un peu pour éviter le flash blanc
        await new Promise(resolve => setTimeout(resolve, 200));
        await SplashScreen.hideAsync();
      }
    };
    
    hideSplash();
  }, [fontsLoaded, isAuthInitialized]);

  // =========================================================================
  // ROUTING GUARD - LOGIQUE CENTRALISÉE
  // =========================================================================
  
  useEffect(() => {
    // Ne pas naviguer pendant l'initialisation
    if (navigationState.isInitializing) {
      if (__DEV__) {
        console.log('[RootLayout] Still initializing, skipping navigation');
      }
      return;
    }
    
    // Ne pas naviguer si déjà en cours de redirection
    if (isRedirecting.current) {
      return;
    }
    
    // Calculer la route cible
    const targetRoute = determineRoute(navigationState);
    const currentRoute = normalizeRoute(pathname || '/');
    const targetNormalized = normalizeRoute(targetRoute);
    
    // Vérifier si redirection nécessaire
    if (!shouldRedirect(currentRoute, targetNormalized, { debug: __DEV__ })) {
      return;
    }
    
    // Protection contre les boucles
    const now = Date.now();
    if (now - lastRedirectTime.current < 100) {
      if (__DEV__) {
        console.warn('[RootLayout] Redirect throttled');
      }
      return;
    }
    
    // Effectuer la redirection
    isRedirecting.current = true;
    lastRedirectTime.current = now;
    
    if (__DEV__) {
      console.log(`[RootLayout] Redirecting: ${currentRoute} → ${targetRoute}`);
      console.log('[RootLayout] Navigation state:', navigationState);
    }
    
    // Enregistrer la transition
    recordRedirect(createTransition(currentRoute, targetRoute, navigationState));
    
    // Navigation
    router.replace(targetRoute);
    
    // Reset flag après un délai
    setTimeout(() => {
      isRedirecting.current = false;
    }, 200);
    
  }, [navigationState, pathname, router]);

  // =========================================================================
  // LOADING STATE
  // =========================================================================
  
  // Afficher loader pendant initialisation
  if (!fontsLoaded || navigationState.isInitializing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  // =========================================================================
  // RENDER
  // =========================================================================
  
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'fade',
          contentStyle: {
            backgroundColor: colors.background,
          },
        }}
      >
        {/* Groupe Auth - Login, Signup, etc. */}
        <Stack.Screen 
          name="(auth)" 
          options={{
            animation: 'fade',
          }}
        />
        
        {/* Groupe Onboarding */}
        <Stack.Screen 
          name="onboarding" 
          options={{
            animation: 'slide_from_right',
          }}
        />
        
        {/* Groupe Tabs - App principale */}
        <Stack.Screen 
          name="(tabs)" 
          options={{
            animation: 'fade',
          }}
        />
        
        {/* Index - Redirige automatiquement */}
        <Stack.Screen 
          name="index" 
          options={{
            animation: 'none',
          }}
        />
      </Stack>
    </>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
});

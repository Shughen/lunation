/**
 * LUNA - Cycle & Cosmos
 * Index - Point d'entrée de l'application
 * 
 * Ce fichier sert uniquement de point d'entrée initial.
 * Toute la logique de redirection est gérée par le RootLayout.
 * 
 * @version 2.0.0 (refactored)
 * @date 27 novembre 2025
 */

import { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet, Text } from 'react-native';
import { useRouter } from 'expo-router';

// Navigation
import { determineRoute } from '@/lib/navigation/routingGuard';
import { useNavigationState } from '@/lib/hooks/useNavigationState';

// Theme
import { colors } from '@/lib/theme/colors';

// ============================================================================
// COMPOSANT
// ============================================================================

export default function Index() {
  const router = useRouter();
  const navigationState = useNavigationState();

  // =========================================================================
  // REDIRECTION AUTOMATIQUE
  // =========================================================================
  
  useEffect(() => {
    // Attendre que l'initialisation soit terminée
    if (navigationState.isInitializing) {
      return;
    }
    
    // Calculer et naviguer vers la route appropriée
    const targetRoute = determineRoute(navigationState);
    
    if (__DEV__) {
      console.log('[Index] Redirecting to:', targetRoute);
    }
    
    // Utiliser replace pour ne pas garder l'index dans l'historique
    router.replace(targetRoute);
  }, [navigationState, router]);

  // =========================================================================
  // RENDER - Écran de chargement temporaire
  // =========================================================================
  
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={styles.text}>Chargement...</Text>
    </View>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  text: {
    marginTop: 16,
    fontSize: 14,
    color: colors.textSecondary,
  },
});

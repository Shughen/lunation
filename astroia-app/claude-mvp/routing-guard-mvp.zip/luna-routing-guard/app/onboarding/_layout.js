/**
 * LUNA - Cycle & Cosmos
 * Onboarding Layout - Layout pour le parcours d'onboarding
 * 
 * ⚠️ IMPORTANT: Ce layout NE DOIT PAS contenir de logique de routing.
 * Toute la logique de navigation est gérée par le RootLayout via le routing guard.
 * 
 * @version 2.0.0 (refactored - suppression redirections)
 * @date 27 novembre 2025
 */

import { Stack } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';

// Theme
import { colors } from '@/lib/theme/colors';

// ============================================================================
// COMPOSANT
// ============================================================================

export default function OnboardingLayout() {
  // =========================================================================
  // ⚠️ AUCUNE LOGIQUE DE ROUTING ICI
  // =========================================================================
  // 
  // AVANT (❌ SUPPRIMÉ):
  // const session = useAuthStore((s) => s.session);
  // const onboardingCompleted = useAuthStore((s) => s.onboardingCompleted);
  // 
  // useEffect(() => {
  //   if (!session) {
  //     router.replace('/(auth)/login');
  //   }
  //   if (session && onboardingCompleted) {
  //     router.replace('/(tabs)/home');
  //   }
  // }, [session, onboardingCompleted]);
  //
  // MAINTENANT: Toute la logique est dans app/_layout.js via routingGuard
  // =========================================================================

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
          contentStyle: {
            backgroundColor: colors.background,
          },
          gestureEnabled: false, // Empêcher swipe back pendant onboarding
        }}
      >
        {/* Écran de bienvenue (index) */}
        <Stack.Screen 
          name="index" 
          options={{
            title: 'Bienvenue',
            animation: 'fade',
          }}
        />
        
        {/* Écran de consentement santé */}
        <Stack.Screen 
          name="consent" 
          options={{
            title: 'Consentement',
            animation: 'slide_from_right',
          }}
        />
        
        {/* Configuration du profil */}
        <Stack.Screen 
          name="profile-setup" 
          options={{
            title: 'Votre profil',
            animation: 'slide_from_right',
          }}
        />
        
        {/* Configuration du cycle */}
        <Stack.Screen 
          name="cycle-setup" 
          options={{
            title: 'Votre cycle',
            animation: 'slide_from_right',
          }}
        />
        
        {/* Tour rapide des fonctionnalités */}
        <Stack.Screen 
          name="tour" 
          options={{
            title: 'Découverte',
            animation: 'slide_from_right',
          }}
        />
      </Stack>
    </View>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
});

/**
 * LUNA - Cycle & Cosmos
 * Tabs Layout - Layout pour les onglets principaux
 * 
 * ⚠️ IMPORTANT: Ce layout NE DOIT PAS contenir de logique de routing.
 * Toute la logique de navigation est gérée par le RootLayout via le routing guard.
 * 
 * @version 2.0.0 (refactored - suppression redirections)
 * @date 27 novembre 2025
 */

import { Tabs } from 'expo-router';
import { View, StyleSheet, Platform } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';

// Theme
import { colors } from '@/lib/theme/colors';

// ============================================================================
// CONFIGURATION DES TABS
// ============================================================================

const TAB_CONFIG = {
  home: {
    title: 'Accueil',
    icon: 'home',
    iconOutline: 'home-outline',
  },
  chat: {
    title: 'Selena',
    icon: 'chatbubble-ellipses',
    iconOutline: 'chatbubble-ellipses-outline',
  },
  calendar: {
    title: 'Calendrier',
    icon: 'calendar',
    iconOutline: 'calendar-outline',
  },
  profile: {
    title: 'Profil',
    icon: 'person',
    iconOutline: 'person-outline',
  },
};

// ============================================================================
// COMPOSANT ICON
// ============================================================================

function TabIcon({ name, focused, color, size }) {
  const config = TAB_CONFIG[name];
  if (!config) return null;
  
  const iconName = focused ? config.icon : config.iconOutline;
  
  return (
    <View style={[styles.iconContainer, focused && styles.iconContainerActive]}>
      <Ionicons name={iconName} size={size} color={color} />
    </View>
  );
}

// ============================================================================
// COMPOSANT PRINCIPAL
// ============================================================================

export default function TabsLayout() {
  // =========================================================================
  // ⚠️ AUCUNE LOGIQUE DE ROUTING ICI
  // =========================================================================
  // 
  // AVANT (❌ SUPPRIMÉ):
  // const session = useAuthStore((s) => s.session);
  // useEffect(() => {
  //   if (!session) {
  //     router.replace('/(auth)/login');
  //   }
  // }, [session]);
  //
  // MAINTENANT: Toute la logique est dans app/_layout.js via routingGuard
  // =========================================================================

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textSecondary,
          tabBarStyle: styles.tabBar,
          tabBarLabelStyle: styles.tabBarLabel,
          tabBarItemStyle: styles.tabBarItem,
        }}
      >
        {/* Onglet Accueil */}
        <Tabs.Screen
          name="home"
          options={{
            title: TAB_CONFIG.home.title,
            tabBarIcon: ({ color, size, focused }) => (
              <TabIcon name="home" focused={focused} color={color} size={size} />
            ),
          }}
        />
        
        {/* Onglet Chat (Selena IA) */}
        <Tabs.Screen
          name="chat"
          options={{
            title: TAB_CONFIG.chat.title,
            tabBarIcon: ({ color, size, focused }) => (
              <TabIcon name="chat" focused={focused} color={color} size={size} />
            ),
          }}
        />
        
        {/* Onglet Calendrier */}
        <Tabs.Screen
          name="calendar"
          options={{
            title: TAB_CONFIG.calendar.title,
            tabBarIcon: ({ color, size, focused }) => (
              <TabIcon name="calendar" focused={focused} color={color} size={size} />
            ),
          }}
        />
        
        {/* Onglet Profil */}
        <Tabs.Screen
          name="profile"
          options={{
            title: TAB_CONFIG.profile.title,
            tabBarIcon: ({ color, size, focused }) => (
              <TabIcon name="profile" focused={focused} color={color} size={size} />
            ),
          }}
        />
      </Tabs>
    </View>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  tabBar: {
    backgroundColor: colors.backgroundSecondary,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    height: Platform.OS === 'ios' ? 85 : 65,
    paddingTop: 8,
    paddingBottom: Platform.OS === 'ios' ? 25 : 10,
  },
  tabBarLabel: {
    fontSize: 11,
    fontWeight: '500',
    marginTop: 2,
  },
  tabBarItem: {
    paddingVertical: 4,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 28,
    height: 28,
  },
  iconContainerActive: {
    // Style actif si nécessaire
  },
});

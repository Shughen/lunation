/**
 * LUNA - Cycle & Cosmos
 * Profile Store Mock - Pour les tests
 * 
 * @version 1.0.0
 */

// Type du profil
interface MockProfile {
  id?: string;
  name?: string | null;
  birth_date?: string | null;
  birth_time?: string | null;
  birth_location?: string | null;
  birth_latitude?: number | null;
  birth_longitude?: number | null;
  last_period?: string | null;
  cycle_length?: number | null;
}

// État mock modifiable
let mockState = {
  profile: null as MockProfile | null,
  isLoading: false,
  error: null as string | null,
  lastUpdated: null as Date | null,
};

// Fonctions mock
const mockActions = {
  loadProfile: jest.fn(async (userId: string) => {
    mockState.isLoading = true;
    // Simuler un délai
    await new Promise(resolve => setTimeout(resolve, 10));
    mockState.isLoading = false;
    return mockState.profile;
  }),
  
  updateProfile: jest.fn(async (updates: Partial<MockProfile>) => {
    if (mockState.profile) {
      mockState.profile = { ...mockState.profile, ...updates };
    }
    mockState.lastUpdated = new Date();
    return { success: true };
  }),
  
  clearProfile: jest.fn(() => {
    mockState.profile = null;
    mockState.lastUpdated = null;
    mockState.error = null;
  }),
  
  setProfile: jest.fn((profile: MockProfile | null) => {
    mockState.profile = profile;
    mockState.lastUpdated = new Date();
  }),
};

// Hook mock
export const useProfileStore = jest.fn((selector?: (state: typeof mockState & typeof mockActions) => any) => {
  const fullState = { ...mockState, ...mockActions };
  
  if (typeof selector === 'function') {
    return selector(fullState);
  }
  
  return fullState;
});

// Helpers pour les tests
export const __resetMockProfileStore = () => {
  mockState = {
    profile: null,
    isLoading: false,
    error: null,
    lastUpdated: null,
  };
  jest.clearAllMocks();
};

export const __setMockProfileState = (newState: Partial<typeof mockState>) => {
  Object.assign(mockState, newState);
};

export const __setMockProfile = (profile: MockProfile | null) => {
  mockState.profile = profile;
};

export const __getMockProfileState = () => ({ ...mockState });

export default useProfileStore;

/**
 * LUNA - Cycle & Cosmos
 * Auth Store Mock - Pour les tests
 * 
 * @version 1.0.0
 */

// État mock modifiable
let mockState = {
  session: null as any,
  user: null as any,
  isInitialized: false,
  isLoading: false,
  onboardingCompleted: false,
  error: null as string | null,
};

// Fonctions mock
const mockActions = {
  initialize: jest.fn(async () => {
    mockState.isInitialized = true;
  }),
  
  login: jest.fn(async (email: string) => {
    mockState.session = { user: { id: 'mock-user-id', email } };
    mockState.user = { id: 'mock-user-id', email };
    return { success: true };
  }),
  
  logout: jest.fn(async () => {
    mockState.session = null;
    mockState.user = null;
    mockState.onboardingCompleted = false;
    return { success: true };
  }),
  
  setOnboardingCompleted: jest.fn((completed: boolean) => {
    mockState.onboardingCompleted = completed;
  }),
  
  clearAuth: jest.fn(() => {
    mockState.session = null;
    mockState.user = null;
    mockState.onboardingCompleted = false;
    mockState.error = null;
  }),
};

// Hook mock
export const useAuthStore = jest.fn((selector?: (state: typeof mockState & typeof mockActions) => any) => {
  const fullState = { ...mockState, ...mockActions };
  
  if (typeof selector === 'function') {
    return selector(fullState);
  }
  
  return fullState;
});

// Helpers pour les tests
export const __resetMockAuthStore = () => {
  mockState = {
    session: null,
    user: null,
    isInitialized: false,
    isLoading: false,
    onboardingCompleted: false,
    error: null,
  };
  jest.clearAllMocks();
};

export const __setMockAuthState = (newState: Partial<typeof mockState>) => {
  Object.assign(mockState, newState);
};

export const __getMockAuthState = () => ({ ...mockState });

export default useAuthStore;
